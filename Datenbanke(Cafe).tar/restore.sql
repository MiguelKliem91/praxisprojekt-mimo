--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mein_shop;
--
-- Name: mein_shop; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mein_shop WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'German_Germany.1252';


ALTER DATABASE mein_shop OWNER TO postgres;

\connect mein_shop

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bestellung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bestellung (
    bestell_id integer NOT NULL,
    produkt_id integer NOT NULL,
    anzahl integer NOT NULL,
    datum_uhrzeit timestamp without time zone NOT NULL
);


ALTER TABLE public.bestellung OWNER TO postgres;

--
-- Name: bestellung_bestell_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bestellung_bestell_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bestellung_bestell_id_seq OWNER TO postgres;

--
-- Name: bestellung_bestell_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bestellung_bestell_id_seq OWNED BY public.bestellung.bestell_id;


--
-- Name: produkt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produkt (
    produkt_id integer NOT NULL,
    name character varying(255) NOT NULL,
    preis numeric(10,2) NOT NULL
);


ALTER TABLE public.produkt OWNER TO postgres;

--
-- Name: produkt_produkt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produkt_produkt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produkt_produkt_id_seq OWNER TO postgres;

--
-- Name: produkt_produkt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produkt_produkt_id_seq OWNED BY public.produkt.produkt_id;


--
-- Name: bestellung bestell_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bestellung ALTER COLUMN bestell_id SET DEFAULT nextval('public.bestellung_bestell_id_seq'::regclass);


--
-- Name: produkt produkt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produkt ALTER COLUMN produkt_id SET DEFAULT nextval('public.produkt_produkt_id_seq'::regclass);


--
-- Data for Name: bestellung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bestellung (bestell_id, produkt_id, anzahl, datum_uhrzeit) FROM stdin;
\.
COPY public.bestellung (bestell_id, produkt_id, anzahl, datum_uhrzeit) FROM '$$PATH$$/4846.dat';

--
-- Data for Name: produkt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produkt (produkt_id, name, preis) FROM stdin;
\.
COPY public.produkt (produkt_id, name, preis) FROM '$$PATH$$/4844.dat';

--
-- Name: bestellung_bestell_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bestellung_bestell_id_seq', 1, false);


--
-- Name: produkt_produkt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produkt_produkt_id_seq', 20, true);


--
-- Name: bestellung bestellung_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bestellung
    ADD CONSTRAINT bestellung_pkey PRIMARY KEY (bestell_id);


--
-- Name: produkt produkt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produkt
    ADD CONSTRAINT produkt_pkey PRIMARY KEY (produkt_id);


--
-- Name: bestellung bestellung_produkt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bestellung
    ADD CONSTRAINT bestellung_produkt_id_fkey FOREIGN KEY (produkt_id) REFERENCES public.produkt(produkt_id);


--
-- PostgreSQL database dump complete
--

